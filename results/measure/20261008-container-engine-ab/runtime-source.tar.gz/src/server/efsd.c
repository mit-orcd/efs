#include "efs/common.h"
#include "efs/log_ts.h"
#include "efs/network.h"
#include "efs/version.h"
#include "server_internal.h"
#include "store_containers.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <poll.h>
#include <fcntl.h>
#include <signal.h>
#include <execinfo.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/resource.h>
#include <time.h>

struct efsd_server *g_server = NULL;


/* Alternate stack so SIGSEGV from stack overflow can still report. */
static char g_efsd_altstack[256 * 1024];

/* Crash diagnostics are best effort: retry interruption, but a short/error
 * stderr write cannot be recovered here. Preserve the interrupted errno. */
static void efsd_diagnostic_write(const void *data, size_t len)
{
    int saved_errno = errno;
    ssize_t written;
    do { written = write(STDERR_FILENO, data, len); }
    while (written < 0 && errno == EINTR);
    errno = saved_errno;
}

static void efsd_fatal_signal(int sig)
{
    const char *name = "signal";
    if (sig == SIGSEGV)
        name = "SIGSEGV";
    else if (sig == SIGBUS)
        name = "SIGBUS";
    else if (sig == SIGABRT)
        name = "SIGABRT";
    else if (sig == SIGILL)
        name = "SIGILL";
    else if (sig == SIGFPE)
        name = "SIGFPE";
    char buf[160];
    int n = snprintf(buf, sizeof(buf), "efsd: fatal %s (%d)\n", name, sig);
    if (n > 0)
        efsd_diagnostic_write(buf, (size_t)n);
    {
        void *frames[64];
        int nf = backtrace(frames, 64);
        backtrace_symbols_fd(frames, nf, STDERR_FILENO);
    }
    signal(sig, SIG_DFL);
    raise(sig);
}

static void efsd_install_crash_handlers(void)
{
#ifdef __SANITIZE_ADDRESS__
    /* Let ASAN own fatal signals so we get a full report. */
    (void)g_efsd_altstack;
    (void)efsd_fatal_signal;
    return;
#endif
    stack_t ss;
    memset(&ss, 0, sizeof(ss));
    ss.ss_sp = g_efsd_altstack;
    ss.ss_size = sizeof(g_efsd_altstack);
    if (sigaltstack(&ss, NULL) != 0)
        fprintf(stderr, "Warning: sigaltstack failed: %s\n", strerror(errno));

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = efsd_fatal_signal;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESETHAND | SA_ONSTACK;
    sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGBUS, &sa, NULL);
    sigaction(SIGABRT, &sa, NULL);
    sigaction(SIGILL, &sa, NULL);
    sigaction(SIGFPE, &sa, NULL);
}

static void usage(const char *prog)
{
    fprintf(stderr,
            "Usage: %s --node-id <id> --addr <addr> --port <port> "
            "--storage <path>[,path...] [--storage <path> ...] "
            "[--quota <bytes>[T|G|M|K]] [--storage-engine files|containers] [--direct-io|--no-direct-io] "
            "[--writers <n>] [--join <host:port>] [--no-persist] [--perf] [--strace] "
            "[--meta-storage <root>]\n"
            "  --storage        1..%d paths (comma and/or repeated).\n"
            "                   Multiple paths: least-queue write placement\n"
            "                   (chunk_index %% N) across disks for parallelism.\n"
            "  --storage-engine files (default) or experimental containers; fresh roots required\n"
            "  --direct-io      O_DIRECT for fragment I/O\n"
            "  --no-direct-io   use the page cache for fragment I/O (default)\n"
            "  --writers <n>    shared writer threads across all storage paths "
            "(default: nproc-%d, 0 = inline)\n"
            "  --meta-storage   directory whose mdraft/ holds the Raft log and KV.\n"
            "                   Default: the first --storage root. Does not move\n"
            "                   an existing mdraft.\n",
            prog, EFS_MAX_STORAGE_PATHS, EFS_WRITERS_RESERVED);
}

static int add_storage_path(struct efsd_server *s, const char *path)
{
    if (!path || !*path)
        return -1;
    if (s->storage_path_count >= EFS_MAX_STORAGE_PATHS) {
        fprintf(stderr, "Too many --storage paths (max %d)\n", EFS_MAX_STORAGE_PATHS);
        return -1;
    }
    strncpy(s->storage_paths[s->storage_path_count], path,
            sizeof(s->storage_paths[0]) - 1);
    s->storage_paths[s->storage_path_count][sizeof(s->storage_paths[0]) - 1] = '\0';
    s->storage_path_count++;
    return 0;
}

static int parse_storage_arg(struct efsd_server *s, const char *arg)
{
    char buf[EFS_MAX_PATH * EFS_MAX_STORAGE_PATHS];
    strncpy(buf, arg, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';
    char *save = NULL;
    for (char *tok = strtok_r(buf, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        while (*tok == ' ' || *tok == '\t')
            tok++;
        if (!*tok)
            continue;
        if (add_storage_path(s, tok) != 0)
            return -1;
    }
    return 0;
}

static int mkdir_p(const char *path)
{
    char tmp[8192];
    strncpy(tmp, path, sizeof(tmp) - 1);
    tmp[sizeof(tmp) - 1] = '\0';

    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            mkdir(tmp, 0755);
            *p = '/';
        }
    }
    return mkdir(tmp, 0755);
}

static pid_t g_perf_pid = -1;

static pid_t start_perf_recorder(pid_t target, const char *perf_path)
{
    char log_dir[8192];
    strncpy(log_dir, perf_path, sizeof(log_dir) - 1);
    log_dir[sizeof(log_dir) - 1] = '\0';
    char *slash = strrchr(log_dir, '/');
    if (slash) {
        *slash = '\0';
        mkdir_p(log_dir);
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork perf");
        return -1;
    }
    if (pid == 0) {
        char pid_str[32];
        snprintf(pid_str, sizeof(pid_str), "%d", (int)target);
        /* -g uses frame pointers (binaries are built with
         * -fno-omit-frame-pointer) so perf report can show call stacks. */
        execlp("perf", "perf", "record", "-g", "-F", "999", "-p", pid_str, "-o",
               perf_path, NULL);
        perror("exec perf");
        _exit(1);
    }
    return pid;
}

static pid_t g_strace_pid = -1;

/* --strace: `strace -f -tt -T -o <path> -p <pid>`. ptrace stops every
 * syscall of every thread, so this is for one node and a wall question
 * (where did a REPORT's finish_ms go), never for a bandwidth number.
 * Needs kernel.yama.ptrace_scope=0 (runtime on the test hosts).
 * EFS_STRACE_EXPR narrows it, e.g. "trace=fsync,fdatasync,pwrite64,futex"
 * (passed as -e). */
static pid_t start_strace_recorder(pid_t target, const char *path)
{
    char log_dir[8192];
    strncpy(log_dir, path, sizeof(log_dir) - 1);
    log_dir[sizeof(log_dir) - 1] = '\0';
    char *slash = strrchr(log_dir, '/');
    if (slash) {
        *slash = '\0';
        mkdir_p(log_dir);
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork strace");
        return -1;
    }
    if (pid == 0) {
        char pid_str[32];
        snprintf(pid_str, sizeof(pid_str), "%d", (int)target);
        const char *expr = getenv("EFS_STRACE_EXPR");
        const char *av[16];
        int n = 0;
        av[n++] = "strace";
        av[n++] = "-f";
        av[n++] = "-tt";
        av[n++] = "-T";
        av[n++] = "-qq";
        av[n++] = "-o";
        av[n++] = path;
        av[n++] = "-p";
        av[n++] = pid_str;
        if (expr && *expr) {
            av[n++] = "-e";
            av[n++] = expr;
        }
        av[n] = NULL;
        execvp("strace", (char *const *)av);
        perror("exec strace");
        _exit(1);
    }
    return pid;
}

/* SIGINT/SIGTERM makes perf finalize perf.data and strace detach; wait
 * up to ~5 s, then SIGKILL. */
static void stop_recorder(pid_t *pidp)
{
    if (*pidp > 0) {
        kill(*pidp, SIGTERM);
        for (int i = 0; i < 50; i++) {
            if (waitpid(*pidp, NULL, WNOHANG) == *pidp)
                break;
            usleep(100000);
        }
        kill(*pidp, SIGKILL);
        waitpid(*pidp, NULL, 0);
        *pidp = -1;
    }
}

static void stop_perf_recorder(void)
{
    stop_recorder(&g_strace_pid);
    stop_recorder(&g_perf_pid);
}

static int parse_host_port(const char *str, char *host, size_t host_len, uint16_t *port)
{
    const char *colon = strrchr(str, ':');
    if (!colon)
        return -1;
    size_t hlen = (size_t)(colon - str);
    if (hlen >= host_len)
        return -1;
    memcpy(host, str, hlen);
    host[hlen] = '\0';
    *port = (uint16_t)atoi(colon + 1);
    return 0;
}

/* Live handler threads (accept path). Used to cap concurrent conns. */
static volatile int g_live_conns;
/* Registered before thread creation, removed before close. Shutdown never
 * operates on a stale descriptor that another thread may have reused. */
static pthread_mutex_t g_conn_lock = PTHREAD_MUTEX_INITIALIZER;
static int g_conn_fds[EFS_SERVER_MAX_CONNS]; /* fd + 1; zero means free */

static int conn_register(int fd)
{
    int found = 0;
    pthread_mutex_lock(&g_conn_lock);
    for (unsigned i = 0; i < EFS_SERVER_MAX_CONNS; i++) {
        if (!g_conn_fds[i]) { g_conn_fds[i] = fd + 1; found = 1; break; }
    }
    pthread_mutex_unlock(&g_conn_lock);
    return found;
}

static void conn_unregister(int fd)
{
    pthread_mutex_lock(&g_conn_lock);
    for (unsigned i = 0; i < EFS_SERVER_MAX_CONNS; i++) {
        if (g_conn_fds[i] == fd + 1) { g_conn_fds[i] = 0; break; }
    }
    pthread_mutex_unlock(&g_conn_lock);
}

static void conn_wake_readers(void)
{
    pthread_mutex_lock(&g_conn_lock);
    for (unsigned i = 0; i < EFS_SERVER_MAX_CONNS; i++)
        if (g_conn_fds[i]) (void)shutdown(g_conn_fds[i] - 1, SHUT_RD);
    pthread_mutex_unlock(&g_conn_lock);
}


static void *conn_thread(void *arg)
{
    int fd = (intptr_t)arg;
    /* No SO_RCVTIMEO: a 60s idle timeout FINed pooled client fds and left
     * the FUSE pool in CLOSE-WAIT, so later PUTs never reached the cluster.
     * Wait forever for the next request; keepalive reaps a dead peer. */
    efs_set_recv_timeout(fd, 0);
    efs_set_send_timeout(fd, EFS_IO_TIMEOUT_MS);
    efs_tcp_keepalive(fd);
    struct efs_conn *conn = efs_conn_wrap_tcp(fd, 1);
    if (!conn) {
        conn_unregister(fd);
        close(fd);
        __sync_fetch_and_sub(&g_live_conns, 1);
        return NULL;
    }
    server_handle_conn(conn);
    conn_unregister(fd);
    efs_conn_destroy(conn); /* QP (if upgraded) + fd */
    server_handler_tls_cleanup();
    __sync_fetch_and_sub(&g_live_conns, 1);
    return NULL;
}

static void sigint_handler(int sig)
{
    (void)sig;
    /* Async-signal-safe only: flip the flag. Do not close(listen_fd) here —
     * racing accept()/other threads on a closed fd has segfaulted on Engaging.
     * Without SA_RESTART, accept() returns EINTR and the loop exits. */
    if (g_server)
        g_server->running = 0;
}

int main(int argc, char **argv)
{
    efs_version_check_argv("efsd", argc, argv);

    /* Install before any work — imagenet load has produced silent SIGSEGVs. */
    efsd_install_crash_handlers();
    efs_log_timestamps_install();

    /* The 1024-fd soft cap put accept() into EMFILE backoff under conn
     * storms (~500 live conns + data files), which wedged new mounts and
     * resync fetches. Raise to the hard cap (524288) at startup. */
    {
        struct rlimit rl;
        if (getrlimit(RLIMIT_NOFILE, &rl) == 0 && rl.rlim_cur < rl.rlim_max) {
            rl.rlim_cur = rl.rlim_max;
            if (setrlimit(RLIMIT_NOFILE, &rl) != 0)
                fprintf(stderr, "setrlimit(RLIMIT_NOFILE) failed: %s\n",
                        strerror(errno));
        }
    }

    struct efsd_server server;
    memset(&server, 0, sizeof(server));
    server.persist_nodes = 1;
    server.direct_io = 0; /* default: page cache; opt in with --direct-io */
    server.nwriters = -1; /* auto: nproc minus standing helper threads */
    server.listen_fd = -1;
    g_server = &server;
    pthread_mutex_init(&server.lock, NULL);
    pthread_cond_init(&server.export_idle_cv, NULL);
    server_peer_pool_init();

    char *join_peer = NULL;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--node-id") == 0 && i + 1 < argc) {
            server.id = (efs_node_id_t)atoi(argv[++i]);
        } else if (strcmp(argv[i], "--addr") == 0 && i + 1 < argc) {
            strncpy(server.addr, argv[++i], sizeof(server.addr) - 1);
        } else if (strcmp(argv[i], "--port") == 0 && i + 1 < argc) {
            server.port = (uint16_t)atoi(argv[++i]);
        } else if (strcmp(argv[i], "--storage") == 0 && i + 1 < argc) {
            if (parse_storage_arg(&server, argv[++i]) != 0) {
                usage(argv[0]);
                return 1;
            }
        } else if (strcmp(argv[i], "--meta-storage") == 0 && i + 1 < argc) {
            strncpy(server.meta_storage, argv[++i],
                    sizeof(server.meta_storage) - 1);
            server.meta_storage[sizeof(server.meta_storage) - 1] = '\0';
        } else if (strcmp(argv[i], "--quota") == 0 && i + 1 < argc) {
            server.quota = efs_parse_quota(argv[++i]);
            if (server.quota == 0) {
                fprintf(stderr, "Invalid --quota value\n");
                usage(argv[0]);
                return 1;
            }
        } else if (strcmp(argv[i], "--storage-engine") == 0 && i + 1 < argc) {
            const char *engine = argv[++i];
            if (!strcmp(engine, "files")) server.storage_engine = 0;
            else if (!strcmp(engine, "containers")) server.storage_engine = 1;
            else { fprintf(stderr, "unknown storage engine: %s\n", engine); return 2; }
        } else if (strcmp(argv[i], "--direct-io") == 0) {
            server.direct_io = 1;
        } else if (strcmp(argv[i], "--no-direct-io") == 0) {
            server.direct_io = 0;
        } else if (strcmp(argv[i], "--writers") == 0 && i + 1 < argc) {
            int n = atoi(argv[++i]);
            if (n < 0 || n > EFS_MAX_WRITERS) {
                fprintf(stderr, "Invalid --writers value (0..%d total)\n",
                        EFS_MAX_WRITERS);
                usage(argv[0]);
                return 1;
            }
            server.nwriters = n;
        } else if (strcmp(argv[i], "--join") == 0 && i + 1 < argc) {
            join_peer = argv[++i];
        } else if (strcmp(argv[i], "--no-persist") == 0) {
            server.persist_nodes = 0;
        } else if (strcmp(argv[i], "--perf") == 0) {
            server.perf = 1;
        } else if (strcmp(argv[i], "--strace") == 0) {
            server.strace = 1;
        } else if (strcmp(argv[i], "--help") == 0) {
            usage(argv[0]);
            return 0;
        } else {
            fprintf(stderr, "Unknown argument: %s\n", argv[i]);
            usage(argv[0]);
            return 1;
        }
    }

    if (server.id == 0 || server.port == 0 || server.storage_path_count == 0) {
        fprintf(stderr, "Missing required arguments\n");
        usage(argv[0]);
        return 1;
    }
    strncpy(server.storage_path, server.storage_paths[0], sizeof(server.storage_path) - 1);
    server.storage_path[sizeof(server.storage_path) - 1] = '\0';

    /* Line-buffer early so join/listen banners show up in harness logs promptly. */
    setlinebuf(stdout);
    setlinebuf(stderr);

    char perf_path[8192];
    perf_path[0] = '\0';
    if (server.perf) {
        const char *pp = getenv("EFS_PERF_PATH");
        if (pp && *pp)
            snprintf(perf_path, sizeof(perf_path), "%s", pp);
        else
            snprintf(perf_path, sizeof(perf_path), "%s/log/perf.data", server.storage_path);
    }
    char strace_path[8192];
    strace_path[0] = '\0';
    if (server.strace) {
        const char *sp = getenv("EFS_STRACE_PATH");
        if (sp && *sp)
            snprintf(strace_path, sizeof(strace_path), "%s", sp);
        else
            snprintf(strace_path, sizeof(strace_path), "%s/log/strace.txt", server.storage_path);
    }

    for (uint32_t pi = 0; pi < server.storage_path_count; pi++) {
        if (mkdir_p(server.storage_paths[pi]) != 0 && errno != EEXIST) {
            fprintf(stderr, "mkdir storage %s: %s\n", server.storage_paths[pi],
                    strerror(errno));
            return 1;
        }
        char subdir[8192];
        snprintf(subdir, sizeof(subdir), "%s/data", server.storage_paths[pi]);
        mkdir_p(subdir);
        snprintf(subdir, sizeof(subdir), "%s/meta", server.storage_paths[pi]);
        mkdir_p(subdir);
        snprintf(subdir, sizeof(subdir), "%s/log", server.storage_paths[pi]);
        mkdir_p(subdir);
    }
    if (server_storage_engine_init(&server) != EFS_OK) return 1;
    fprintf(stderr, "storage-engine=%s direct_io=%s\n",
            server.storage_engine ? "containers" : "files", server.direct_io ? "on" : "off");
    if (server.meta_storage[0] &&
        mkdir_p(server.meta_storage) != 0 && errno != EEXIST) {
        fprintf(stderr, "mkdir meta-storage %s: %s\n", server.meta_storage,
                strerror(errno));
        return 1;
    }

    server.nodes[0].id = server.id;
    strncpy(server.nodes[0].addr, server.addr, sizeof(server.nodes[0].addr) - 1);
    server.nodes[0].port = server.port;
    server_format_storage_paths(&server, server.nodes[0].storage_path,
                                sizeof(server.nodes[0].storage_path));
    server.nodes[0].quota = server.quota;
    server.nodes[0].used = 0;
    server.node_count = 1;

    server_load_nodes(&server);

    /* Refresh this process's row by id — never smash nodes[0], which may be a peer
     * after load (that bug duplicated one id and dropped another). */
    server_sync_local_membership(&server);
    /* Prefer meta/usage.bin; fall back to one full data/ scan. */
    server_init_local_usage(&server);

    /* Start listening first. If the configured address/port cannot be bound,
       fail immediately before contacting peers. */
    server.listen_fd = efs_listen_tcp(server.addr, server.port, EFS_LISTEN_BACKLOG);
    if (server.listen_fd < 0) {
        fprintf(stderr, "Failed to listen on %s:%u: %s\n",
                server.addr, server.port, strerror(errno));
        return 1;
    }

    /* SIGTERM may run on a handler rather than interrupt main's accept.
     * Poll bounds flag observation; nonblocking accept cannot outwait it. */
    int listen_flags = fcntl(server.listen_fd, F_GETFL, 0);
    if (listen_flags < 0 || fcntl(server.listen_fd, F_SETFL,
                                  listen_flags | O_NONBLOCK) < 0) {
        perror("nonblocking listener");
        close(server.listen_fd);
        return 1;
    }

    if (join_peer) {
        char host[64];
        uint16_t port;
        if (parse_host_port(join_peer, host, sizeof(host), &port) != 0) {
            fprintf(stderr, "Invalid join address: %s\n", join_peer);
            close(server.listen_fd);
            return 1;
        }
        if (server_join_cluster(&server, host, port) != 0) {
            fprintf(stderr,
                    "Could not join cluster at %s; starting as standalone and retrying in background\n",
                    join_peer);
            strncpy(server.rejoin_addr, host, sizeof(server.rejoin_addr) - 1);
            server.rejoin_addr[sizeof(server.rejoin_addr) - 1] = '\0';
            server.rejoin_port = port;
            server_start_rejoin(&server);
        } else {
            server_save_nodes(&server);
        }
    } else if (server.node_count > 1) {
        if (server_rejoin_cluster(&server) != 0) {
            fprintf(stderr,
                    "Could not rejoin cluster from persisted peers; starting as standalone and retrying in background\n");
            server_start_rejoin(&server);
        } else {
            server_save_nodes(&server);
        }
    } else {
        server_save_nodes(&server);
    }

    /* Do not rebuild 2+1 meta pages on this thread. A large export (tens of
     * thousands of pages) used to block accept() for minutes after a bounce,
     * so joiners never came up and the client timed out every GET. Catch-up
     * rebuilds in the background; GET_CHUNK is served from disk immediately. */

    {
        struct sigaction sa;
        memset(&sa, 0, sizeof(sa));
        sa.sa_handler = sigint_handler;
        sigemptyset(&sa.sa_mask);
        /* Do not set SA_RESTART: we want accept() to surface EINTR as a
         * fallback if close(listen_fd) races with the syscall entry. */
        sigaction(SIGINT, &sa, NULL);
        sigaction(SIGTERM, &sa, NULL);
    }
    server.running = 1;
    if (server_writer_pool_start(&server) != 0) {
        fprintf(stderr, "Failed to start writer pool (%d threads, %u paths)\n",
                server.nwriters, server.storage_path_count);
        return 1;
    }
    server_start_heartbeat(&server);
    if (server_raft_host_start(&server) != 0) {
        fprintf(stderr, "raft-host: start failed\n");
        server_writer_pool_stop(&server);
        return 1;
    }

    {
        const char *stripe = (server.storage_path_count > 1) ? "leastq" : "none";
        char storage_disp[EFS_MAX_PATH];
        uint64_t used_disp = 0;
        server_format_storage_paths(&server, storage_disp, sizeof(storage_disp));
        struct efs_node *local = server_local_node(&server);
        if (local)
            used_disp = local->used;
        char ver[256];
        printf("%s, build=%s: node %u listening on %s:%u, storage=%s "
               "(%u paths, stripe=%s), used=%llu, quota=%llu, direct_io=%s, "
               "writers=%d shared\n",
               efs_version_string("efsd", ver, sizeof(ver)), EFS_BUILD_ID,
               server.id, server.addr, server.port, storage_disp,
               server.storage_path_count, stripe,
               (unsigned long long)used_disp,
               (unsigned long long)server.quota,
               server.direct_io ? "on" : "off",
               server.nwriters);
    }
    fflush(stdout);

    if (server.perf) {
        g_perf_pid = start_perf_recorder(getpid(), perf_path);
        if (g_perf_pid < 0) {
            fprintf(stderr, "Warning: could not start perf recorder; continuing without profiling\n");
        }
    }
    if (server.strace) {
        g_strace_pid = start_strace_recorder(getpid(), strace_path);
        if (g_strace_pid < 0)
            fprintf(stderr, "Warning: could not start strace; continuing without it\n");
        else
            fprintf(stderr, "efsd strace pid=%d -> %s\n", (int)g_strace_pid, strace_path);
    }

    while (server.running) {
        struct pollfd listener = { .fd = server.listen_fd, .events = POLLIN };
        int ready = poll(&listener, 1, 250);
        if (!server.running)
            break;
        if (ready < 0) {
            if (errno == EINTR) continue;
            perror("listener poll");
            break;
        }
        if (!ready) continue;
        struct sockaddr_storage addr;
        socklen_t addrlen = sizeof(addr);
        int fd = accept(server.listen_fd, (struct sockaddr *)&addr, &addrlen);
        if (fd < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) continue;
            if (errno == EINTR) {
                /* SIGINT/SIGTERM clear running. Leaving the loop is
                 * what runs stop_perf_recorder; staying here left efsd
                 * up and the perf file without a footer. */
                if (!server.running)
                    break;
                continue;
            }
            /* EMFILE/ENFILE: do not tear down the accept loop — back off so
             * existing handlers can finish and free fds, then resume. */
            if (errno == EMFILE || errno == ENFILE || errno == ENOBUFS ||
                errno == ENOMEM) {
                fprintf(stderr,
                        "accept: %s (live_conns=%d); backing off\n",
                        strerror(errno), g_live_conns);
                usleep(10 * 1000);
                continue;
            }
            if (errno != EINVAL)
                perror("accept");
            break;
        }

        /* Some platforms inherit the listener's nonblocking flag. Handler
         * framing expects blocking accepted sockets with explicit deadlines. */
        int accepted_flags = fcntl(fd, F_GETFL, 0);
        if (accepted_flags < 0 || fcntl(fd, F_SETFL,
                                       accepted_flags & ~O_NONBLOCK) < 0) {
            close(fd);
            continue;
        }

        int live = __sync_add_and_fetch(&g_live_conns, 1);
        if (live > EFS_SERVER_MAX_CONNS) {
            __sync_fetch_and_sub(&g_live_conns, 1);
            close(fd);
            /* Over-cap: back off like EMFILE so a conn storm doesn't spin. */
            usleep(10 * 1000);
            continue;
        }

        if (!conn_register(fd)) {
            __sync_fetch_and_sub(&g_live_conns, 1);
            close(fd);
            continue;
        }
        pthread_t tid;
        if (efsd_pthread_create(&tid, conn_thread, (void *)(intptr_t)fd) != 0) {
            conn_unregister(fd);
            __sync_fetch_and_sub(&g_live_conns, 1);
            close(fd);
        } else {
            pthread_detach(tid);
        }
    }

    if (server.listen_fd >= 0) {
        close(server.listen_fd);
        server.listen_fd = -1;
    }
    stop_perf_recorder();

    /* Idle pooled readers have no receive timeout. Wake them, then retain
     * shared state until every handler and its TLS cleanup has completed.
     * An operator timeout must retain the daemon, never force a live UAF. */
    conn_wake_readers();
    for (unsigned waited_ms = 0; __sync_add_and_fetch(&g_live_conns, 0) > 0; ) {
        usleep(50 * 1000);
        waited_ms += 50;
        if (waited_ms % 15000 == 0)
            fprintf(stderr, "shutdown: waiting for %d live handlers; state retained\n",
                    __sync_add_and_fetch(&g_live_conns, 0));
    }

    server_writer_pool_stop(&server);
    server_usage_flush_dirty(&server);

    /* Nothing to replay on the way down: the Raft log is the durability
     * boundary and recovery is WAL replay at next start. */
    server_raft_host_stop();
    server_peer_pool_shutdown();
    server_storage_engine_close(&server);
    pthread_mutex_destroy(&server.lock);
    for (uint32_t i = 0; i < server.export_count; i++)
        efs_export_free(&server.exports[i]);
    return 0;
}
