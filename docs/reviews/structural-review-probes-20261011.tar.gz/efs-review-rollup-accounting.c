#include "efs/metadata.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 struct efs_export e;efs_export_init(&e,1,"accounting");
 assert(efs_export_create_with_ino(&e,16,EFS_ROOT_INO,S_IFREG|0644,1000,1000,"file")==16);
 uint64_t before=efs_export_staged_bytes(&e);
 assert(efs_export_set_size_norollup(&e,16,4096)==EFS_OK);
 uint64_t after=efs_export_staged_bytes(&e);
 assert(e.pending_rollup_cap==64 && before==after);
 printf("deferred rollup allocation: capacity=%llu payload=%llu bytes; staged estimate before/after=%llu/%llu\n",(unsigned long long)e.pending_rollup_cap,(unsigned long long)(e.pending_rollup_cap*(sizeof(efs_ino_t)+sizeof(int64_t)+sizeof(uint8_t))),(unsigned long long)before,(unsigned long long)after);
 efs_export_free(&e);
}
