#include "efs/metadata.h"
#include <assert.h>
#include <stdio.h>
static void counts(struct efs_export *e,efs_ino_t ino,uint64_t f,uint64_t d){
 struct efs_inode x;assert(efs_export_get_inode(e,ino,&x)==EFS_OK);
 assert(x.imm_files==f && x.imm_dirs==d);
}
int main(void){
 struct efs_export e;efs_export_init(&e,1,"counts");
 assert(efs_export_create_with_ino(&e,16,EFS_ROOT_INO,S_IFDIR|0755,1000,1000,"a")==16);
 assert(efs_export_create_with_ino(&e,17,EFS_ROOT_INO,S_IFDIR|0755,1000,1000,"b")==17);
 assert(efs_export_create_with_ino(&e,18,16,S_IFREG|0644,1000,1000,"file")==18);
 counts(&e,EFS_ROOT_INO,0,2);counts(&e,16,1,0);counts(&e,17,0,0);
 assert(efs_export_link(&e,18,17,"alias")==EFS_OK);
 counts(&e,16,1,0);counts(&e,17,1,0);
 assert(efs_export_set_size_norollup(&e,18,8192)==EFS_OK);
 assert(efs_export_set_mtime_ns_norollup(&e,18,123,456)==EFS_OK);
 efs_export_ensure_rollups(&e);
 counts(&e,16,1,0);counts(&e,17,1,0);
 assert(efs_export_unlink_name_ex(&e,17,"alias",0)==EFS_OK);
 counts(&e,17,0,0);
 assert(efs_export_rename(&e,18,17,"moved")==EFS_OK);
 counts(&e,16,0,0);counts(&e,17,1,0);
 assert(efs_export_unlink_name_ex(&e,17,"moved",0)==EFS_OK);
 counts(&e,17,0,0);
 struct efs_inode x;assert(efs_export_get_inode(&e,17,&x)==EFS_OK);assert(x.nlink==2);
 efs_export_free(&e);puts("immediate child counts: create/link/deferred size+mtime/rename/unlink OK");
}
