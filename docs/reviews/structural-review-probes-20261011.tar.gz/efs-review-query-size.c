#include "efs/query_catalog.h"
#include "query_disk.h"
#include "query_build_time.h"
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

struct record { uint32_t key, klen, val, vlen; };
struct partition {
    uint32_t refs, count, capacity, used, arena_cap;
    uint64_t revision, bytes, limit;
    /* Exact bounds for retained key kinds; absent transaction kinds are O(1). */
    uint32_t kind_begin[256], kind_end[256];
    struct record *records;
    uint8_t *arena;
    struct efs_name_index *names;
};
struct contribution {
    efs_ino_t parent;
    struct efs_query_rollup rollup;
    uint32_t children;
};
struct edge_fold {
    uint32_t refs, count, capacity, nlinks, link_capacity;
    uint64_t dependencies[64], bytes;
    struct contribution *items;
    const struct efs_name_entry **links;
};
struct inode_value { struct efs_meta_row row; struct efs_meta_stat stat; };
struct inode_block {
    uint32_t refs, count;
    uint64_t bytes, dependencies[64];
    struct inode_value values[];
};
struct directory_value {
    struct efs_query_rollup rollup;
    const struct efs_name_entry *link;
    uint32_t children;
};
struct node { struct inode_value *inode; struct directory_value *dir; };
struct efs_query_catalog {
    struct efs_query_disk *disk;
    struct efs_query_build_times times;
    struct partition *part[4096];
    struct edge_fold *fold[4096];
    struct node *nodes;
    struct inode_block *inodes[4096], *building;
    uint32_t building_at;
    uint32_t refs, count, capacity, rebuilt, refolded, reused_edges;
    uint32_t node_begin[4097]; /* Ordered inode ranges for each retained partition. */
    uint64_t bytes, limit;
    struct efs_kv kv;
    int (*stop)(void *);
    void *stop_ctx;
};

#include <stdio.h>
int main(void){printf("query catalog wrapper size: %zu bytes\n",sizeof(struct efs_query_catalog));printf("backend-specific pointer/index arrays: %zu bytes\n",sizeof(((struct efs_query_catalog*)0)->part)+sizeof(((struct efs_query_catalog*)0)->fold)+sizeof(((struct efs_query_catalog*)0)->inodes)+sizeof(((struct efs_query_catalog*)0)->node_begin));}
