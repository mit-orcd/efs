
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
typedef uint64_t efs_ino_t;
struct efs_export { uint64_t pending_rollup_count,pending_rollup_cap;efs_ino_t *pending_rollup_inos;int64_t *pending_rollup_deltas;uint8_t *pending_rollup_touch; };
static int allocation_call;
static void *forced_realloc(void *old,size_t n) {
 if (++allocation_call==2) return NULL;
 void *p=malloc(n);assert(p);memcpy(p,old,n/2);free(old);return p;
}
#define realloc forced_realloc
static int pending_rollup_note(struct efs_export *ex, efs_ino_t ino,
                               int64_t size_delta, int touch)
{
    for (uint64_t i = 0; i < ex->pending_rollup_count; i++) {
        if (ex->pending_rollup_inos[i] == ino) {
            ex->pending_rollup_deltas[i] += size_delta;
            if (touch)
                ex->pending_rollup_touch[i] = 1;
            return 0;
        }
    }
    if (ex->pending_rollup_count >= ex->pending_rollup_cap) {
        uint64_t ncap = ex->pending_rollup_cap ? ex->pending_rollup_cap * 2 : 64;
        efs_ino_t *ninos = realloc(ex->pending_rollup_inos, ncap * sizeof(*ninos));
        int64_t *ndeltas = realloc(ex->pending_rollup_deltas, ncap * sizeof(*ndeltas));
        uint8_t *ntouch = realloc(ex->pending_rollup_touch, ncap * sizeof(*ntouch));
        if (!ninos || !ndeltas || !ntouch) {
            free(ninos);
            free(ndeltas);
            free(ntouch);
            return -1;
        }
        ex->pending_rollup_inos = ninos;
        ex->pending_rollup_deltas = ndeltas;
        ex->pending_rollup_touch = ntouch;
        ex->pending_rollup_cap = ncap;
    }
    uint64_t i = ex->pending_rollup_count++;
    ex->pending_rollup_inos[i] = ino;
    ex->pending_rollup_deltas[i] = size_delta;
    ex->pending_rollup_touch[i] = touch ? 1 : 0;
    return 0;
}
#undef realloc
int main(void){
 struct efs_export e={.pending_rollup_count=64,.pending_rollup_cap=64};
 e.pending_rollup_inos=calloc(64,sizeof(efs_ino_t));
 e.pending_rollup_deltas=calloc(64,sizeof(int64_t));
 e.pending_rollup_touch=calloc(64,1);
 int rc=pending_rollup_note(&e,999,4,1);assert(rc==-1);
 puts("partial realloc failure returned -1; now execute ordinary owner cleanup");fflush(stdout);
 free(e.pending_rollup_inos);free(e.pending_rollup_deltas);free(e.pending_rollup_touch);
}
