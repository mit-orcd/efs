#include "efs/metadata.h"
#include <stdio.h>
struct review_rollup_row {
    efs_ino_t ino;
    efs_ino_t parent;
    uint32_t mode;
    uid_t uid;
    gid_t gid;
    uint64_t size;
    uint64_t mtime;
    uint32_t mtime_nsec;
    uint32_t ctime_nsec; /* was padding; sizeof was unchanged at the time */
    uint64_t ctime;
    uint64_t atime;
    uint32_t nlink;
    uint32_t name_off; /* byte offset into the owning slab's name arena */
    uint16_t name_len;
    /* Owning slab, so a row pointer resolves to its arena and its slot in
     * O(1). Bounded by EFS_META_INO_PAGE_MAX slabs, which fits u16. */
    uint16_t slab_idx;
    /* A stat served from this table returned atime with nsec 0 until
     * Sep 30 2026 (ecopy --verify: 119 "(atime)" mismatches). */
    uint32_t atime_nsec; /* was padding */
    uint64_t imm_files, imm_dirs;
    efs_ino_t pack_ino;
    uint32_t pack_off;
    uint32_t pack_len;
    /* W20: chunks in this client's table, plus dirty dcache chunks that
     * are not in the table yet. st_blocks reads the sum. Not serialized. */
    uint32_t present_chunks;
    uint32_t present_extra;
    /* D17: the server-side present-chunk count from the last adopted row
     * image. st_blocks takes the larger of this and the local sum. */
    uint64_t alloc_chunks;
};
struct review_combined_row {
    efs_ino_t ino;
    efs_ino_t parent;
    uint32_t mode;
    uid_t uid;
    gid_t gid;
    uint64_t size;
    uint64_t mtime;
    uint32_t mtime_nsec;
    uint32_t ctime_nsec; /* was padding; sizeof was unchanged at the time */
    uint64_t ctime;
    uint64_t atime;
    uint32_t nlink;
    uint32_t name_off; /* byte offset into the owning slab's name arena */
    uint16_t name_len;
    /* Owning slab, so a row pointer resolves to its arena and its slot in
     * O(1). Bounded by EFS_META_INO_PAGE_MAX slabs, which fits u16. */
    uint16_t slab_idx;
    /* A stat served from this table returned atime with nsec 0 until
     * Sep 30 2026 (ecopy --verify: 119 "(atime)" mismatches). */
    uint32_t atime_nsec; /* was padding */
    uint64_t imm_files, imm_dirs;
    /* W20: chunks in this client's table, plus dirty dcache chunks that
     * are not in the table yet. st_blocks reads the sum. Not serialized. */
    uint32_t present_chunks;
    uint32_t present_extra;
    /* D17: the server-side present-chunk count from the last adopted row
     * image. st_blocks takes the larger of this and the local sum. */
    uint64_t alloc_chunks;
};
int main(void){printf("private row: current=%zu; no recursive rollups=%zu; no recursive rollups/pack=%zu bytes\n",sizeof(struct efs_inode_mem),sizeof(struct review_rollup_row),sizeof(struct review_combined_row));}
