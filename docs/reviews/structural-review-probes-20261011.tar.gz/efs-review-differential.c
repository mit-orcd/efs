#include "efs/metadata.h"
#include <stdint.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
static uint32_t seed=0x91989a7;
static uint32_t rnd(void){seed=seed*1664525u+1013904223u;return seed;}
static uint64_t h=1469598103934665603ULL;
static void mix(uint64_t x){h=(h^x)*1099511628211ULL;}
static void name(unsigned n,char*b){snprintf(b,24,"f-%u",n);}
int main(void){
 struct efs_export e;efs_export_init(&e,1,"diff");
 for(int d=0;d<16;d++){
  char b[24];snprintf(b,sizeof(b),"d-%d",d);
  efs_ino_t parent=d<4?EFS_ROOT_INO:16+(d%4);
  assert(efs_export_create_with_ino(&e,16+d,parent,S_IFDIR|0755,1000,1000,b)==16+d);
 }
 for(unsigned j=0;j<20000;j++){
  unsigned a=rnd()%16,b=rnd()%16,n=rnd()%200,m=rnd()%200,op=rnd()%7;
  char na[24],nb[24];name(n,na);name(m,nb);
  struct efs_inode x;int rc=0;
  switch(op){
  case 0:rc=(int)efs_export_create_with_ino(&e,1000+j,16+a,S_IFREG|0644,1000,1000,na);break;
  case 1:rc=efs_export_unlink_name_ex(&e,16+a,na,0);break;
  case 2:rc=efs_export_rename_at(&e,16+a,na,16+b,nb);break;
  case 3:rc=efs_export_lookup(&e,16+a,na,&x);if(!rc)rc=efs_export_link(&e,x.ino,16+b,nb);break;
  case 4:rc=efs_export_lookup(&e,16+a,na,&x);if(!rc)rc=efs_export_set_size_norollup(&e,x.ino,(rnd()%1024)*512ULL);break;
  case 5:rc=efs_export_lookup(&e,16+a,na,&x);if(!rc)rc=efs_export_set_mtime_ns_norollup(&e,x.ino,1000+j,1234);break;
  case 6:efs_export_ensure_rollups(&e);break;
  }
  mix((uint32_t)rc);
  for(int d=0;d<16;d++){
   rc=efs_export_get_inode(&e,16+d,&x);assert(!rc);
   mix(x.imm_files);mix(x.imm_dirs);mix(x.nlink);mix(efs_inode_dir_is_spread(&x));
  }
  rc=efs_export_lookup(&e,16+b,nb,&x);mix((uint32_t)rc);
  if(!rc){mix(x.ino);mix(x.parent);mix(x.mode);mix(x.nlink);mix(x.size);}
 }
 printf("20000 seeded mutations: attrs/immediate counters/routing digest=%016llx\n",(unsigned long long)h);
 efs_export_free(&e);
}
