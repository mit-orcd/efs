Structural review probe bundle — October 11, 2026

Base: 48a2719d19fb5a6b0464935c70a967a1f1a86236
These are exact local review probes and scratch copies, not production patches.
Sources remain unchanged on devel-code-review. Scratch metadata keeps public
structures and immediate counters but disables recursive local stats; it leaves
obsolete no-op compatibility stubs/state, so it is not merge-ready.

Extract this bundle to a temporary directory. From the pinned repository root,
set PROBE_DIR to that extraction directory. Use cc on the local machine:

cc -std=c99 "$PROBE_DIR/efs-review-patch-probe.c" -o /tmp/review-patch
/tmp/review-patch
cc -std=c99 "$PROBE_DIR/efs-review-recorder.c" -o /tmp/review-recorder
/tmp/review-recorder
cc -std=c99 -fsanitize=undefined "$PROBE_DIR/efs-review-endian.c" -o /tmp/review-endian
/tmp/review-endian
cc -std=c99 -fsanitize=address -g "$PROBE_DIR/efs-review-oom.c" -o /tmp/review-oom
/tmp/review-oom

The OOM probe is EXPECTED to fail with an AddressSanitizer double-free. It
forces successful reallocations to move and one allocation to fail. No live
cluster or production process is accessed. Recorder syscalls are all stubbed.

For both the simple counter and differential probe, compile once against
src/meta/metadata.c and once against $PROBE_DIR/efs-review-metadata.c:
cc -std=c99 -D_GNU_SOURCE -Iinclude "$PROBE_DIR/efs-review-counts.c" src/meta/metadata.c src/common/common.c -o /tmp/review-counts
cc -std=c99 -D_GNU_SOURCE -Iinclude "$PROBE_DIR/efs-review-counts.c" "$PROBE_DIR/efs-review-metadata.c" src/common/common.c -o /tmp/review-counts-scratch
/tmp/review-counts
/tmp/review-counts-scratch
Repeat with efs-review-differential.c; expected digest afdaf51ba528758e. This is an unsharded memory probe.

Existing staging test against scratch:
cc -std=c99 -D_GNU_SOURCE -Iinclude tests/test_stage_evict.c "$PROBE_DIR/efs-review-metadata.c" src/common/common.c -o /tmp/review-stage
/tmp/review-stage
Scratch mode-removal syntax checks:
cc -std=c99 -D_GNU_SOURCE -Iinclude -Isrc/client -fsyntax-only "$PROBE_DIR/efs-review-ops-modes.c"
cc -std=c99 -D_GNU_SOURCE -Iinclude -Isrc/client -fsyntax-only "$PROBE_DIR/efs-review-write-modes.c"

Type-layout probes require the same pinned include tree, plus -Isrc/meta for
efs-review-query-size.c. The measured layouts were on a 64-bit Mac ABI.

Runtime probes do not establish Linux, mounted FUSE, wire/disk compatibility,
sharded routing, race or live-cluster acceptance. Read the report for limits.

The baseline efs-review-rollup-accounting.c probe compiles against src/meta/metadata.c and src/common/common.c, with -D_GNU_SOURCE -Iinclude. It confirms pending-array allocation is absent from the staging estimate.
