
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
typedef uint64_t efs_ino_t;
#define EFS_OK 0
struct efs_chunk_entry { uint64_t generation; };
struct dcache_init { int have_base; uint64_t bg; int full; uint32_t off, len; };
static unsigned char captured[16];
static int merges;
static int dcache_patch(efs_ino_t i,uint32_t c,uint32_t o,const uint8_t*s,uint32_t n){return -1;}
#define dcache_patch_sparse dcache_patch
static void *efs_buf_alloc(uint32_t n){return malloc(n);}
static void efs_buf_free(void*p,uint32_t n){free(p);}
static int export_chunk_copy(efs_ino_t i,uint32_t c,struct efs_chunk_entry*out){out->generation=7;return 0;}
static int efs_rdcache_get(efs_ino_t i,uint32_t c,uint8_t*p,uint32_t n){return -1;}
static int efs_client_fetch_published_chunk(efs_ino_t i,uint32_t c,uint8_t*p,uint32_t n){return -1;}
static int dcache_merge_owned(efs_ino_t i,uint32_t c,uint32_t o,const uint8_t*s,uint32_t n,uint8_t*p,uint32_t z,const struct dcache_init*in){assert(z==16); memcpy(captured,p,z); merges++; free(p);return 0;}
static int dcache_load_and_patch(efs_ino_t ino, uint32_t ci, uint32_t off,
                                 const uint8_t *src, uint32_t len, uint32_t cs)
{
    if (dcache_patch(ino, ci, off, src, len) == 0)
        return 0;

    uint8_t *chunk = efs_buf_alloc(cs);
    if (!chunk)
        return -1;

    int have_base = 0;
    uint64_t bg = 0;
    struct efs_chunk_entry ce;
    if (export_chunk_copy(ino, ci, &ce) == 0)
        bg = ce.generation;
    if (efs_rdcache_get(ino, ci, chunk, cs) == 0) {
        have_base = 1;
    } else {
        if (bg &&
            efs_client_fetch_published_chunk(ino, ci, chunk, cs) == EFS_OK)
            have_base = 1;
        if (!have_base)
            memset(chunk, 0, cs);
    }
    memcpy(chunk + off, src, len);
    {
        struct dcache_init in = { have_base, bg, 0, off, len };
        int folded = dcache_merge_owned(ino, ci, off, src, len, chunk, cs,
                                        &in);

        if (folded < 0) {
            efs_buf_free(chunk, cs);
            return -1;
        }
    }
    return 0;
}

static int dcache_load_sparse(efs_ino_t ino, uint32_t ci, uint32_t off,
                              const uint8_t *src, uint32_t len, uint32_t cs)
{
    uint8_t *chunk;
    int have_base = 0;
    uint64_t bg = 0;
    struct efs_chunk_entry ce;

    if (dcache_patch_sparse(ino, ci, off, src, len) == 0)
        return 0;

    chunk = efs_buf_alloc(cs);
    if (!chunk)
        return -1;
    /* Same as load_and_patch: if this chunk is already published, RMW
     * onto those bytes. Zeros+range was only correct for a brand-new
     * chunk. After close, adopt can drop the have_base=1 slot; the next
     * O_APPEND then missed the prefix and PUT NULs + new bytes
     * (basic_terminal_cp_cat). Skip GET when there is no mapping — a
     * peer leftover name is the W1 first-fsync DECODE. */
    if (export_chunk_copy(ino, ci, &ce) == 0) {
        bg = ce.generation;
        if (efs_client_fetch_published_chunk(ino, ci, chunk, cs) == EFS_OK ||
            efs_client_fetch_published_chunk(ino, ci, chunk, cs) == EFS_OK)
            have_base = 1;
        else {
            /* A published chunk we could not read. Zeros plus this range
             * would PUT over the prefix (concurrent_appends). */
            efs_buf_free(chunk, cs);
            return -1;
        }
    }
    if (!have_base)
        memset(chunk, 0, cs);
    memcpy(chunk + off, src, len);
    {
        struct dcache_init in = { have_base, bg, 0, off, len };
        int folded = dcache_merge_owned(ino, ci, off, src, len, chunk, cs,
                                        &in);

        if (folded < 0) {
            efs_buf_free(chunk, cs);
            return -1;
        }
        /* Folded into a slot another writer already dirtied. That slot
         * owns the bytes and the ranges. Clearing nrange here kept only
         * this write; the next flush then published the rest as zeros.
         * Otherwise the store installed have_base/base_gen/range with
         * the buffer (dcache_init). */
    }
    return 0;
}

int main(void){
 const uint8_t patch[]={65,66};
 int regular=dcache_load_and_patch(1,0,4,patch,2,16);
 assert(regular==0 && merges==1);
 for(int j=0;j<16;j++) assert(captured[j]==(j==4?65:j==5?66:0));
 int sparse=dcache_load_sparse(1,0,4,patch,2,16);
 assert(sparse==-1 && merges==1);
 puts("mapped base fetch failure: regular=0 with zero-filled base admitted; sparse=-1 without merge");
}
