#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
static void probe_0(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v >> 8);
    p[1] = (uint8_t)v;
}
static void probe_1(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static void probe_2(uint8_t *p, uint64_t v)
{
    probe_1(p, (uint32_t)(v >> 32));
    probe_1(p + 4, (uint32_t)v);
}
static uint32_t probe_3(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static uint64_t probe_4(const uint8_t *p)
{
    return ((uint64_t)probe_3(p) << 32) | probe_3(p + 4);
}
static void probe_5(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v >> 8);
    p[1] = (uint8_t)v;
}
static uint16_t probe_6(const uint8_t *p)
{
    return (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
}
static void probe_7(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static void probe_8(uint8_t *p, uint64_t v)
{
    probe_7(p, (uint32_t)(v >> 32));
    probe_7(p + 4, (uint32_t)v);
}
static uint32_t probe_9(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static uint64_t probe_10(const uint8_t *p)
{
    return ((uint64_t)probe_9(p) << 32) | probe_9(p + 4);
}
static void probe_11(uint8_t *p, uint32_t v)
{
    for (unsigned i = 0; i < 4; i++)
        p[i] = (uint8_t)(v >> (24 - 8 * i));
}
static void probe_12(uint8_t *p, uint64_t v)
{
    for (unsigned i = 0; i < 8; i++)
        p[i] = (uint8_t)(v >> (56 - 8 * i));
}
static uint32_t probe_13(const uint8_t *p)
{
    uint32_t v = 0;
    for (unsigned i = 0; i < 4; i++)
        v = (v << 8) | p[i];
    return v;
}
static uint64_t probe_14(const uint8_t *p)
{
    uint64_t v = 0;
    for (unsigned i = 0; i < 8; i++)
        v = (v << 8) | p[i];
    return v;
}
static void probe_15(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static uint32_t probe_16(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static uint64_t probe_17(const uint8_t *p)
{
    return (uint64_t)probe_16(p)<<32 | probe_16(p+4);
}
static uint64_t probe_18(const uint8_t *p)
{
    return ((uint64_t)probe_16(p) << 32) | probe_16(p+4);
}
static void probe_19(uint8_t *p, uint64_t n)
{
    probe_15(p, (uint32_t)(n >> 32)); probe_15(p+4, (uint32_t)n);
}
static void probe_20(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static void probe_21(uint8_t *p, uint64_t v)
{
    probe_20(p, (uint32_t)(v >> 32));
    probe_20(p + 4, (uint32_t)v);
}
static uint32_t probe_22(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static uint64_t probe_23(const uint8_t *p)
{
    return ((uint64_t)probe_22(p) << 32) | probe_22(p + 4);
}
static void probe_24(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static void probe_25(uint8_t *p, uint64_t v)
{
    int i;

    for (i = 7; i >= 0; i--) {
        p[i] = (uint8_t)v;
        v >>= 8;
    }
}
static void probe_26(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static void probe_27(uint8_t *p, uint64_t v)
{
    int i;

    for (i = 7; i >= 0; i--) {
        p[i] = (uint8_t)v;
        v >>= 8;
    }
}
static uint32_t probe_28(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static void probe_29(uint8_t *p, uint64_t v)
{
    int i;
    for (i = 7; i >= 0; i--) {
        p[i] = (uint8_t)v;
        v >>= 8;
    }
}
static uint64_t probe_30(const uint8_t *p)
{
    uint64_t v = 0;
    int i;
    for (i = 0; i < 8; i++)
        v = (v << 8) | p[i];
    return v;
}
static void probe_31(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static uint32_t probe_32(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static void probe_33(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static void probe_34(uint8_t *p, uint64_t v)
{
    probe_33(p, (uint32_t)(v >> 32));
    probe_33(p + 4, (uint32_t)v);
}
static uint32_t probe_35(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static uint64_t probe_36(const uint8_t *p)
{
    return ((uint64_t)probe_35(p) << 32) | probe_35(p + 4);
}
static void probe_37(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static uint32_t probe_38(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static void probe_39(uint8_t *p, uint64_t v)
{
    int i;

    for (i = 7; i >= 0; i--) {
        p[i] = (uint8_t)v;
        v >>= 8;
    }
}
static uint64_t probe_40(const uint8_t *p)
{
    return ((uint64_t)p[0] << 56) | ((uint64_t)p[1] << 48) |
           ((uint64_t)p[2] << 40) | ((uint64_t)p[3] << 32) |
           ((uint64_t)p[4] << 24) | ((uint64_t)p[5] << 16) |
           ((uint64_t)p[6] << 8) | (uint64_t)p[7];
}
static void probe_41(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static void probe_42(uint8_t *p, uint64_t v)
{
    probe_41(p, (uint32_t)(v >> 32));
    probe_41(p + 4, (uint32_t)v);
}
static uint32_t probe_43(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static uint64_t probe_44(const uint8_t *p)
{
    return ((uint64_t)probe_43(p) << 32) | probe_43(p + 4);
}
static void probe_45(uint8_t *p, uint64_t v)
{
    p[0] = (uint8_t)(v >> 56);
    p[1] = (uint8_t)(v >> 48);
    p[2] = (uint8_t)(v >> 40);
    p[3] = (uint8_t)(v >> 32);
    p[4] = (uint8_t)(v >> 24);
    p[5] = (uint8_t)(v >> 16);
    p[6] = (uint8_t)(v >> 8);
    p[7] = (uint8_t)v;
}
static void probe_46(uint8_t *p, uint64_t v)
{
    int i;
    for (i = 7; i >= 0; i--) {
        p[i] = (uint8_t)v;
        v >>= 8;
    }
}
static void probe_47(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static uint64_t probe_48(const uint8_t *p)
{
    return ((uint64_t)p[0] << 56) | ((uint64_t)p[1] << 48) |
           ((uint64_t)p[2] << 40) | ((uint64_t)p[3] << 32) |
           ((uint64_t)p[4] << 24) | ((uint64_t)p[5] << 16) |
           ((uint64_t)p[6] << 8) | (uint64_t)p[7];
}
static uint32_t probe_49(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static void probe_50(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static void probe_51(uint8_t *p, uint64_t v)
{
    probe_50(p, (uint32_t)(v >> 32));
    probe_50(p + 4, (uint32_t)v);
}
static uint32_t probe_52(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static uint64_t probe_53(const uint8_t *p)
{
    return ((uint64_t)probe_52(p) << 32) | probe_52(p + 4);
}
static void probe_54(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static void probe_55(uint8_t *p, uint64_t v)
{
    probe_54(p, (uint32_t)(v >> 32));
    probe_54(p + 4, (uint32_t)v);
}
static uint32_t probe_56(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static uint64_t probe_57(const uint8_t *p)
{
    return ((uint64_t)probe_56(p) << 32) | probe_56(p + 4);
}
static void probe_58(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}
static void probe_59(uint8_t *p, uint64_t v)
{
    probe_58(p, (uint32_t)(v >> 32));
    probe_58(p + 4, (uint32_t)v);
}
static uint32_t probe_60(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static uint64_t probe_61(const uint8_t *p)
{
    return ((uint64_t)probe_60(p) << 32) | (uint64_t)probe_60(p + 4);
}
int main(void){uint64_t r=0x123456789abcdefULL;uint8_t b[12];
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<16)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<16)-1);memset(b,0xa5,sizeof(b));
probe_0(b+1,v);for(unsigned k=0;k<2;k++)assert(b[k+1]==(uint8_t)(v>>((2-1-k)*8)));assert(b[0]==0xa5 && b[3]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_1(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_2(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_3(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_4(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<16)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<16)-1);memset(b,0xa5,sizeof(b));
probe_5(b+1,v);for(unsigned k=0;k<2;k++)assert(b[k+1]==(uint8_t)(v>>((2-1-k)*8)));assert(b[0]==0xa5 && b[3]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<16)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<16)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<2;k++)b[k+1]=(uint8_t)(v>>((2-1-k)*8));assert(probe_6(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_7(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_8(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_9(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_10(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_11(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_12(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_13(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_14(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_15(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_16(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_17(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_18(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_19(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_20(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_21(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_22(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_23(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_24(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_25(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_26(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_27(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_28(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_29(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_30(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_31(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_32(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_33(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_34(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_35(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_36(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_37(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_38(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_39(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_40(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_41(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_42(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_43(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_44(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_45(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_46(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_47(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_48(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_49(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_50(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_51(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_52(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_53(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_54(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_55(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_56(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_57(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
probe_58(b+1,v);for(unsigned k=0;k<4;k++)assert(b[k+1]==(uint8_t)(v>>((4-1-k)*8)));assert(b[0]==0xa5 && b[5]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
probe_59(b+1,v);for(unsigned k=0;k<8;k++)assert(b[k+1]==(uint8_t)(v>>((8-1-k)*8)));assert(b[0]==0xa5 && b[9]==0xa5);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & ((UINT64_C(1)<<32)-1);if(t==0)v=0;if(t==1)v=((UINT64_C(1)<<32)-1);memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<4;k++)b[k+1]=(uint8_t)(v>>((4-1-k)*8));assert(probe_60(b+1)==v);
}
for(unsigned t=0;t<1000;t++){r^=r<<13;r^=r>>7;r^=r<<17;uint64_t v=r & UINT64_MAX;if(t==0)v=0;if(t==1)v=UINT64_MAX;memset(b,0xa5,sizeof(b));
for(unsigned k=0;k<8;k++)b[k+1]=(uint8_t)(v>>((8-1-k)*8));assert(probe_61(b+1)==v);
}
puts("62 big-endian helpers: 1000 values each, golden bytes and unaligned buffers PASS");}
