
#include <sys/types.h>
#include <signal.h>
#include <assert.h>
#include <stdio.h>
static int reaped,kill_after_reap,calls;
static int fake_kill(pid_t p,int sig){if(reaped)kill_after_reap++;calls++;return 0;}
static pid_t fake_wait(pid_t p,int *s,int options){reaped=1;return p;}
static int fake_sleep(unsigned int n){return 0;}
#define kill fake_kill
#define waitpid fake_wait
#define usleep fake_sleep
#define WNOHANG 1
static void stop_recorder(pid_t *pidp)
{
    if (*pidp > 0) {
        kill(*pidp, SIGTERM);
        for (int i = 0; i < 50; i++) {
            if (waitpid(*pidp, NULL, WNOHANG) == *pidp)
                break;
            usleep(100000);
        }
        kill(*pidp, SIGKILL);
        waitpid(*pidp, NULL, 0);
        *pidp = -1;
    }
}
int main(void){pid_t p=123;stop_recorder(&p);assert(p==-1);assert(calls==2 && kill_after_reap==1);puts("recorder stop: sends SIGKILL after successful child reap (all syscalls stubbed)");}
